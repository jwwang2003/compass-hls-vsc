cd /home/jwwang/HGBO-DSE/id123456/MachSuite/bfs
open_project bfs_motpe_fl_prj_p1
add_files bfs.c
add_files local_support.c
set_top bfs
open_solution -reset solution
set_part xc7vx485tffg1761-2
create_clock -period 10
source /home/jwwang/HGBO-DSE/id123456/artifacts/MachSuite/motpe_fl_ds/bfs/p1/script/dir_98.tcl
csynth_design
exit
